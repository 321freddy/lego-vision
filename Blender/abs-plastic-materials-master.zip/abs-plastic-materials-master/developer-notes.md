Improvements:
- Add subsurface scattering values to various uncommon mat colors that need it
